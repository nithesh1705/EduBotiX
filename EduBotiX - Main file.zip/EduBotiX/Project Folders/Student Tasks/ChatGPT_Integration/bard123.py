from flask import Flask, request, jsonify
from bardapi import Bard

app = Flask(__name__)

# Replace the token with your actual token
token = "YggKu6dZjZHaDo-gyX7anv0ibJfOlK5wsoWjc1xbMOio7qZ6Colk41lf45IZ-KqIROAqdw."
bard = Bard(token)

def get_answer(question):
    return bard.get_answer(question)['content']

@app.route('/get_answer', methods=['POST'])
def get_answer_endpoint():
    data = request.get_json()
    question = data.get('question')
    
    if not question:
        return jsonify({'error': 'No question provided'}), 400
    final_question = question + "Answer Shortly"
    answer_text = get_answer(final_question)
    response = {'answer': answer_text}
    return jsonify(response)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=500, debug=True)
